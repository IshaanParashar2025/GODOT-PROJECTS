# 2D Car Steering

![alt](http://kidscancode.org/godot_recipes/4.x/img/car_sliders.png)

Tutorial:
http://kidscancode.org/godot_recipes/4.x/2d/car_steering
